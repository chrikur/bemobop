<template>
  <Map :beciclestations="beciclestations" />
</template>

<script>
import { getAllStations } from "./services/stadgentService";
import Map from "./components/Map.vue";
export default {
  name: "App",
  components: {
    Map,
  },
  data: () => ({
    beciclestations: [],
  }),
  async created() {
    this.refreshStationInterval();
  },
  methods: {
    async refreshStationInterval() {
      this.beciclestations = await getAllStations();
      this.interval = setInterval(async () => {
        this.beciclestations = await getAllStations();
      }, 1000 * 60);
    },
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
#map {
  height: 100%;
  width: 100%;
}

#map-container {
  height: 100vh;
  width: auto;
}

#mapbox {
  position: absolute;
  width: 100%;
  top: 0px; /* The height of the header */
  bottom: 0;
  left: 0;
}
.mapboxgl-canvas {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
</style>
