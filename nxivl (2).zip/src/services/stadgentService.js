const API_URL =
  "https://data.stad.gent/api/records/1.0/search/?dataset=real-time-bezettingen-fietsenstallingen-gent";

export async function getAllStations() {
  return fetch(API_URL)
    .then(async (response) => {
      const data = await response.json();

      // check for error response
      if (!response.ok) {
        // get error message from body or default to response statusText
        const error = (data && data.message) || response.statusText;
        return Promise.reject(error);
      }

      return data.records.map((bicycleStation) => {
        const { fields } = bicycleStation;
        return {
          ...fields,
          location: [fields.locatie[1], fields.locatie[0]]
        };
      });
    })
    .catch((error) => {
      this.errorMessage = error;
      console.error("There was an error!", error);
    });
}

export default {
  getAllStations
};
