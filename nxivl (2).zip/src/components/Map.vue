<template>
  <div id="mapbox" class="h-screen" />
</template>

<script>
import mapboxgl from "mapbox-gl/dist/mapbox-gl.js";
export default {
  props: {
    beciclestations: {
      type: Array,
      required: true,
    },
  },
  data: () => ({
    map: null,
    currentMarkers: [],
  }),
  watch: {
    beciclestations() {
      this.updateStations();
    },
  },
  mounted() {
    this.initMap();
    this.updateStations();
  },
  methods: {
    initMap() {
      mapboxgl.accessToken =
        "pk.eyJ1IjoidGVycmF2ZXgiLCJhIjoiY2tseXg5YXpiMzZ2aDJubndyZWF5Zjh0NiJ9.zCleZxPZhTiXuBSb6KxS6Q";
      this.map = new mapboxgl.Map({
        container: "mapbox",
        style: "mapbox://styles/mapbox/streets-v11",
        center: [3.733333, 51.049999],
        zoom: 10,
      });
      this.map.addControl(new mapboxgl.FullscreenControl());
      this.map.addControl(new mapboxgl.NavigationControl());
    },
    updateStations() {
      this.currentMarkers.forEach((marker) => {
        marker.remove();
      });
      this.currentMarkers = [];
      console.log(this.beciclestations);
      this.beciclestations.forEach((s) => {
        this.createMarker(s);
      });
    },
    createMarker(station) {
      const marker = new mapboxgl.Marker({
        color: "#FF0000",
      })
        .setLngLat(station.location)
        .setPopup(
          new mapboxgl.Popup()
            .setLngLat(station.location)
            .setHTML(
              "<br /><h1>" +
                station.facilityname +
                "</h1>vrije plaatsen : " +
                station.occupiedplaces +
                "  Totaal : " +
                station.totalplaces
            )
            .addTo(this.map)
        )
        .addTo(this.map);
      const markerElement = marker.getElement();
      markerElement.style.cursor = "pointer";
      this.currentMarkers.push(marker);
    },
  },
};
</script>
<style scoped>
</style>